Downloadify
==========

Provides a library for dealing with client-side file download

## License

(c) 2009 by Douglas Neiner. Licensed under the MIT license
