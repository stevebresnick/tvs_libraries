Mustache JS
==========

Used in other libraries as template language.

