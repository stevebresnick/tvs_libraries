FileSaver
==========

Provides a library for dealing with saving files client side

## License

X11/MIT
