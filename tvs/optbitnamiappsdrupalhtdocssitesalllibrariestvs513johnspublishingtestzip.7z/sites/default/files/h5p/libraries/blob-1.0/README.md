Blob
==========

Provides a library for dealing with files

## License

X11/MIT

By Eli Grey, http://eligrey.com
By Devin Samarin, https://github.com/eboyjr
