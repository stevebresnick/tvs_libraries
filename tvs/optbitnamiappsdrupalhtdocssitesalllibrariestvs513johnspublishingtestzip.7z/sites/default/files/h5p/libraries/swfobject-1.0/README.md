SWF Object
==========

Provides a library for dealing with flash files.

## License

MIT
