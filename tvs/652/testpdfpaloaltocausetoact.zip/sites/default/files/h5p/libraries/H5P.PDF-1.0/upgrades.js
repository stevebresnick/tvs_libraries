/*global H5P*/
/** @namespace H5PUpgrades */
var H5PUpgrades = H5PUpgrades || {};

H5PUpgrades['H5P.PDF'] = (function ($) {
  return {
  };
})(H5P.jQuery);
